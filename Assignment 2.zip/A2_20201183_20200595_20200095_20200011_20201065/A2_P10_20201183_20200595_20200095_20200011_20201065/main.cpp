#include<bits/stdc++.h>
using namespace std;
struct node{
    int data;
    node *left;
    node *right;
    //creat new node!
    node(int d){
        data=d;
        this->left= this->right= nullptr;
    }
}*r;
//insert function!!
void insert(const int& el) {
    node *p = r, *prev = 0;
    while (p != 0) { // find a place for inserting new node;
        prev = p;
        if (el < p->data)
            p = p->left;
        else p = p->right;
    }
    if (r == 0) // tree is empty;
        r = new  node (el);
    else if (el < prev->data)
        prev->left = new node(el);
    else prev->right = new node(el);
}
//function sum number of minimum element and return sum!
int sumOfMin(node* root,int k,int &c){
    if(root== nullptr)
        return 0;
    int result= sumOfMin(root->left,k,c);
    if(c>=k)
        return result;
    result=result+root->data;
    c++;
    return result+ sumOfMin(root->right,k,c);
}
int main(){
    int k=3,c=0;
    //first test
    node* top= new node(54);
    top->left= new node(51);
    top->right= new node(75);
    top->left->left= new node(49);
    top->left->right= new node(52);
    top->right->left= new node(74);
    top->right->right= new node(85);
    cout<<"First test Case:  "<<sumOfMin(top,k,c)<<endl;
    //second!
    c=0;
    int kk;
    node* t= new node(8);
    t->left= new node(7);
    t->right= new node(10);
    t->left->left= new node(2);
    t->right->left= new node(9);
    t->right->right= new node(13);
    cout<<"Enter number of k: ";
    cin>>kk;
    cout<<"Second test Case:  "<<sumOfMin(t,kk,c)<<endl;
    //third!
    c=0;
    node* to= new node(8);
    to->left= new node(5);
    to->right= new node(11);
    to->left->left= new node(2);
    to->left->left->right= new node(3);
    to->left->right= new node(7);
    cout<<"Enter number of k: ";
    cin>>kk;
    cout<<"Third test Case:  "<<sumOfMin(to,kk,c)<<endl;
    //fourth!
    c=0;
    node* n= new node(50);
    n->left= new node(53);
    n->right= new node(20);
    n->right->left= new node(11);
    n->right->right= new node(22);
    n->left->left= new node(52);
    n->left->right= new node(78);
    cout<<"Enter number of k: ";
    cin>>kk;
    cout<<"Fourth test Case:  "<<sumOfMin(n,kk,c)<<endl;
    //fifth!!
    c=0;
    node* T= new node(8);
    T->left= new node(3);
    T->right= new node(10);
    T->right->right= new node(14);
    T->right->right->left= new node(13);
    T->left->left= new node(1);
    T->left->right= new node(6);
    T->left->right->left= new node(4);
    T->left->right->right= new node(7);
    cout<<"Enter number of k: ";
    cin>>kk;
    cout<<"Fifth test Case:  "<<sumOfMin(T,kk,c)<<endl;

}
