
#include <bits/stdc++.h>
using namespace std;


//Node class.
template<class T>
        class BSTNode
                {
                public:
                    T key;
                    BSTNode* right;//greater nodes on right.
                    BSTNode* left;//smaller nodes on left.
                public:
                    //setting initial values to left and right pointers.
                    BSTNode()
                    {
                        right = NULL;
                        left = NULL;
                        //leaf node
                    }

                };

//class with all used functions .
template<class T>
        class BSTFCI
                {
                public:
                    //Base node in BST.
                    BSTNode<T>* root;
                public:
                    BSTFCI()
                    {
                        root = NULL;
                    }


                    //Recursion Function - Inserting new node to the binary search tree.
                    //helper
                    BSTNode<T>* Insert_Node(T DATA, BSTNode<T>* node)
                    {
                        //InCase there is no node create root node.
                        if (node == NULL)
                        {
                            node = new BSTNode<T>;
                            node->key = DATA;
                            node->left = node->right = NULL;
                        }

                        //InCase given key > node key  Go right subtree.
                        else if (DATA > node->key)
                            node->right = Insert_Node(DATA, node->right);

                        //InCase given key < node key Go left subtree.
                        else if (DATA < node->key)
                            node->left = Insert_Node(DATA, node->left);

                        return node;
                    }

                    //Function to call insert function.
                    void Insert(T DATA)
                    {
                        root = Insert_Node(DATA, root);
                    }

                    //function to calculate the height of each node .
                    template<class T2>
                            int height(BSTNode<T2>* node);

                    //Function returns true if BST balanced.
                    template<class T2>
                            friend bool isBalanced( BSTNode<T2> *root);

                    //Recursion Function to check if two subtrees are identical.
                    template <typename T2>
                    friend bool areIdentical(BSTNode<T2> * root1, BSTNode<T2> * root2);

                    template <typename T2>
                    friend bool isSubtree(BSTNode<T2> *t, BSTNode<T2> *S);

                    template <typename T2>
                    friend bool isSubTree(BSTFCI<T2>* t1, BSTFCI<T2>* t2);

                    //function to print all nodes in the given range.
                    template <typename T2>
                    friend void PrintRange(BSTNode<T2> *root, int k1, int k2);

                };

//function to calculate the height of each node .
template<class T2>
        int height(BSTNode<T2>* node)
        {
            if(node == NULL)
                return 0;
            //height = 1 + max of left height and right heights
            return 1 + max(height(node->left),height(node->right));
        }

        //Function returns true if BST balanced.
        template<class T2>
                bool isBalanced( BSTNode<T2> *root)
                {
                    int lh; //hight of left subtree.
                    int rh; //hight of right subtree.

                    if(root == NULL)
                        return 1;

                    //Hight of left and right subtree.
                    lh = height(root->left);
                    rh = height(root->right);
                    //difference between left and right must be less than or equal to 1.
                    if( abs(lh-rh) <= 1 && isBalanced(root->left) && isBalanced(root->right))
                        return 1;
                    //tree is not balanced.
                    return 0;
                }

                //Recursion Function to check if two nodes are identical.
                template<class T2>
                        bool areIdentical(BSTNode<T2> * root1, BSTNode<T2> *root2)
                        {
                            if (root1 == NULL && root2 == NULL)     //Both equal NULLs
                                return true;

                            if (root1 == NULL || root2 == NULL)     //if both nodes are not equal
                                return false;

                            return (root1->key == root2->key &&                 //check both nodes are equal
                            areIdentical(root1->left, root2->left) &&   //check left nodes are equal
                            areIdentical(root1->right, root2->right));  //check right nodes are equal
                        }

                        //Recursion Function to check if two nodes are identical.
                        template<class T2>
                                bool isSubtree(BSTNode<T2> *t, BSTNode<T2> *S)
                                {
                                    if (S == NULL)
                                        return true;

                                    if (t == NULL)
                                        return false;

                                    if (areIdentical(t, S))
                                        return true;

                                    return isSubtree(t->left, S) ||
                                    isSubtree(t->right, S);
                                }

                                template<class T2>
                                        bool isSubTree(BSTFCI<T2>* t1, BSTFCI<T2>* t2)
                                        {
                                            return isSubtree(t1->root, t2->root);
                                        }

                                        //function to print all nodes in the given range.
                                        template <typename T2>
                                        void PrintRange(BSTNode<T2> *root, int k1, int k2)
                                        {
                                            if ( root == NULL )
                                                return ;
                                            // If root->data is greater than k1,then data in left subtree.
                                            if ( k1 < root->key )
                                                PrintRange(root->left, k1, k2);
                                            // if root's data lies in range,then prints root's data .
                                            if ( k1 <= root->key && k2 >= root->key )
                                                cout<<root->key<<" ";
                                            // If root->data is less than k1,then data in right subtree.
                                            if ( k2 > root->key )
                                                PrintRange(root->right, k1, k2);
                                        }

                                        int main()
                                        {
                                            BSTFCI <int> * test1 = new BSTFCI <int>();
                                            BSTFCI <int> * test2 = new BSTFCI <int>();
                                            BSTFCI <int> * test3 = new BSTFCI <int>();
                                            BSTFCI <int> * test11 = new BSTFCI <int>();
                                            BSTFCI <int> * test22 = new BSTFCI <int>();
                                            BSTFCI <int> * test33 = new BSTFCI <int>();

                                            test33->Insert(3);
                                            test33->Insert(2);
                                            test33->Insert(4);
                                            test33->Insert(1);

                                            test1->Insert(20);
                                            test1->Insert(8);
                                            test1->Insert(22);
                                            test1->Insert(4);
                                            test1->Insert(12);


                                            test2->Insert(6);
                                            test2->Insert(7);
                                            test2->Insert(3);
                                            test2->Insert(2);
                                            test2->Insert(5);

                                            test3->Insert(8);
                                            test3->Insert(4);
                                            test3->Insert(12);

                                            test11->Insert(5);
                                            test11->Insert(3);
                                            test11->Insert(7);
                                            test11->Insert(2);
                                            test11->Insert(4);
                                            test11->Insert(9);
                                            test11->Insert(1);
                                            // test11->Insert(NULL);
                                            test11->Insert(8);
                                            test11->Insert(10);

                                            test22->Insert(9);
                                            test22->Insert(8);
                                            test22->Insert(10);


                                            cout<<"testing is balance"<<endl;

                                            cout<<"test 1 : ";
                                            if(!isBalanced(test1->root))
                                                cout <<"unBalanced"<< endl;
                                            else
                                                cout <<"Balanced"<< endl;
                                            cout<<"test 2 : ";

                                            if(!isBalanced(test3->root))
                                                cout <<"unBalanced"<< endl;
                                            else
                                                cout <<"Balanced"<< endl;
                                            cout<<"test 3 : ";
                                            if(!isBalanced(test2->root))
                                                cout <<"unBalanced"<< endl;
                                            else
                                                cout <<"Balanced"<< endl;
                                            cout<<"test 4 : ";
                                            if(!isBalanced(test22->root))
                                                cout <<"unBalanced"<< endl;
                                            else
                                                cout <<"Balanced"<< endl;
                                            cout<<"test 5 : ";
                                            if(!isBalanced(test11->root))
                                                cout <<"unBalanced"<< endl;
                                            else
                                                cout <<"Balanced"<< endl;

                                            cout<<"testing IsSubtree"<<endl;

                                            cout<<"test 1 : ";
                                            if(isSubTree(test11, test22))
                                                cout<<"true"<<endl;
                                            else
                                                cout<<"false"<<endl;
                                            cout<<"test 2 : ";
                                            if(isSubTree(test11, test33))
                                                cout<<"true"<<endl;
                                            else
                                                cout<<"false"<<endl;
                                            cout<<"test 3 : ";
                                            if(isSubTree(test1, test3))
                                                cout<<"true"<<endl;
                                            else
                                                cout<<"false"<<endl;
                                            cout<<"test 4 : ";
                                            if(isSubTree(test1, test2))
                                                cout<<"true"<<endl;
                                            else
                                                cout<<"false"<<endl;
                                            cout<<"test 5 : ";
                                            if(isSubTree(test11, test3))
                                                cout<<"true"<<endl;
                                            else
                                                cout<<"false"<<endl;

                                            cout<<"testing print in range "<<endl;
                                            cout<<"test 1 : ";
                                            PrintRange(test11->root, 3,6);
                                            cout<<endl;
                                            cout<<"test 2 : ";
                                            PrintRange(test11->root, 8,15);
                                            cout<<endl;
                                            cout<<"test 3 : ";
                                            PrintRange(test11->root, 6,6);
                                            cout<<endl;
                                            cout<<"test 4 : ";
                                            PrintRange(test2->root, 2,6);
                                            cout<<endl;
                                            cout<<"test 5 : ";

                                            PrintRange(test1->root, 8,10);
                                            cout<<endl;

                                            return 0;
                                        }
