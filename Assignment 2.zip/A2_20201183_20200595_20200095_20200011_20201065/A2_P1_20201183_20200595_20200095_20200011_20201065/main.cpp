
#include <bits/stdc++.h>
using namespace std;

template<class type>
        class Stack {
        private:
            struct Node {
                type item;
                Node *next{};
            };
            int length=0;
            Node *top;
        public:
            Stack() {
                top = nullptr;
            }

            bool isEmpty() {
                return top == nullptr;
            }

            //push item to stack
            void push(type element) {
                Node *newItemPtr = new Node;
                newItemPtr->item = element;
                newItemPtr->next = top;
                top = newItemPtr;
                length++;
            }

            //remove top
            void pop() {
                if (isEmpty())
                    cout << "Stack is empty" << endl;
                else {
                    Node *temp = top;
                    top = top->next;
                    temp = temp->next = nullptr;
                    delete temp;
                }
                length--;
            }

            //get top element
            type getTop(){
                return top->item;
            }

            int size(){
                return length;
            }

        };

string simplify(string A) {
    Stack<string> st;

    string dir, res;

    res.append("/");

    int len_A = A.length();

    for (int i = 0; i < len_A; i++) {

        dir.clear();

        while (A[i] == '/')
            i++;

        while (i < len_A && A[i] != '/') {
            dir.push_back(A[i]);
            i++;
        }

        if (dir.compare("..") == 0) {
            if (!st.isEmpty())
                st.pop();
        } else if (dir.compare(".") == 0)
            continue;

        else if (dir.length() != 0)
            st.push(dir);
    }

    Stack<string> st1;
    while (!st.isEmpty()) {
        st1.push(st.getTop());
        st.pop();
    }

    while (!st1.isEmpty()) {
        string temp = st1.getTop();

        if (st1.size() != 1)
            res.append(temp + "/");
        else
            res.append(temp);

        st1.pop();
    }
    return res;
}

int main() {

    string str1 = "/home/";
    cout << simplify(str1) << endl;

    string str2 = "/../";
    cout << simplify(str2) << endl;

    string str3 = "/home//foo/";
    cout << simplify(str3) << endl;

    string str4 = "/hello//";
    cout << simplify(str4) << endl;

    return 0;
}

