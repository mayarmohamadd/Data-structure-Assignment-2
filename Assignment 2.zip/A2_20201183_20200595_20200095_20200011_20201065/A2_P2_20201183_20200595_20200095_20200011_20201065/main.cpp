#include <iostream>
using namespace std;

template<class t>
class LinkedQueue
{
private:
	struct node
	{
		t item;
		node* next;
	};
	int size;
	node* front, * rear;
public:
	LinkedQueue();
	bool empty();
	void enqueue(t elem);
	void dequeue();
	t getfront();
	t getrear();
	void clear();
	void print();
	int getsize();
	int calc_time(int index);
	~LinkedQueue();
};

template<class t>
LinkedQueue<t>::LinkedQueue()
{
	front = rear = NULL;
	size = 0;
}

template<class t>
bool LinkedQueue<t>::empty()
{
	return size == 0;
}

template<class t>
void LinkedQueue<t>::enqueue(t elem)
{
	if (empty())
	{
		front = new node;
		front->item = elem;
		front->next = NULL;
		rear = front;
	}
	else
	{
		node* temp = new node;
		temp->item = elem;
		temp->next = NULL;
		rear->next = temp;
		rear = temp;
	}
	size++;
}

template<class t>
void LinkedQueue<t>::dequeue()
{
	if (empty())
	{
		cout << "empty queue,cannot dequeue...";
		return;
	}
	else
	{
		node* temp = front;
		if (size==1)
		{
			front = NULL;
			rear = NULL;
		}
		else
		{
			front = front->next;
		}
		delete temp;
		size--;
	}
}

template<class t>
 t LinkedQueue<t>::getfront()
{
	 if (empty())
		 cout << "empty queue,cannot dequeue...";
	 else
	     return front->item;
}

 template<class t>
 t LinkedQueue<t>::getrear()
 {
	 if (empty())
	 {
		 cout << "empty queue,cannot dequeue...";
		 return;
	 }
	 return rear->item;
 }

 template<class t>
 void LinkedQueue<t>::clear()
 {
	 node* temp;
	 while (front != NULL)
	 {
		 temp = front;
		 front = front->next;
		 delete temp;
	 }
	 rear = NULL;
 }

 template<class t>
 void LinkedQueue<t>::print()
 {
	 node* temp = front;
	 while (temp != NULL)
	 {
		 cout << temp->item;
		 temp = temp->next;
	 }

 }

 template<class t>
 int LinkedQueue<t>::getsize()
 {
	 return size;
 }

template<class t>
int LinkedQueue<t>::calc_time(int index)
 {
	int c = 0, n=0;
	node* temp = front;
	node* cur = front;
	while (c != index)
	{
		if(temp->next!=NULL)
		temp = temp->next;
		c++;
	}
	while (cur != NULL)
	{
		if ((cur->item) > 0)
			n++;
		cur->item = (cur->item) - 1;
		cur = cur->next;
		if (temp->item != 0 && cur == NULL)
		{
			cur = front;
		}
		if (temp->item == 0)
			break;
	}
	return n;

 }
template<class t>
LinkedQueue<t>::~LinkedQueue()
{
	clear();
}

int main()
{
	LinkedQueue<int> q;

	//tese case1
	q.enqueue(2);
	q.enqueue(3);
	q.enqueue(2);
	cout << "tese case 1:" << q.calc_time(2) << endl;

	LinkedQueue<int> q1;
	//tese case2
	q1.enqueue(5);
	q1.enqueue(1);
	q1.enqueue(1);
	q1.enqueue(1);
	q1.enqueue(1);
	cout << "tese case 2:" << q1.calc_time(0) << endl;

	LinkedQueue<int> q2;
	//tese case3
	q2.enqueue(3);
	q2.enqueue(9);
	q2.enqueue(4);
	cout << "tese case 3:" << q2.calc_time(2) << endl;

	LinkedQueue<int> q3;
	//tese case4
	q3.enqueue(5);
	q3.enqueue(4);
	q3.enqueue(1);
	q3.enqueue(2);
	q3.enqueue(9);
	q3.enqueue(3);
	cout << "tese case 4:" << q3.calc_time(5) << endl;

	LinkedQueue<int> q4;
	//tese case5
	q4.enqueue(2);
	q4.enqueue(4);
	q4.enqueue(6);
	q4.enqueue(8);
	cout << "tese case 5:" << q4.calc_time(1) << endl;
}
