#include<bits/stdc++.h>
using namespace std;
template <class type>
        class Queue {
        private:
            struct Node {
                type item;
                Node *next;
            };
            Node *frontPtr;
            Node *rearPtr;
            int length;
        public:
            Queue() : frontPtr(nullptr), rearPtr(nullptr), length(0) {}

            bool isEmpty() const {
                return length == 0;
            }

            void push(int element) {
                Node *newPtr = new Node;
                newPtr->item = element;
                newPtr->next = nullptr;
                if (isEmpty()) {
                    rearPtr = frontPtr = newPtr;

                } else {
                    rearPtr->next = newPtr;
                    rearPtr = newPtr;
                }
                length++;
            }
            void pop(){
                if(isEmpty()){
                    cout<<"empty"<<endl;
                }
                else if(length==1) {
                    delete frontPtr;
                    rearPtr = nullptr;
                    length = 0;
                }
                else{
                    Node* tempPtr=frontPtr;
                    frontPtr=frontPtr->next;
                    delete tempPtr;
                    length--;
                }
            }
            int front(){
                if(isEmpty())
                    cout<<"empty"<<endl;

                return frontPtr->item;
            }
            int size(){
                return length;
            }
        };
class Stack
        {
        private:
            Queue<int>q;
        public:
            void push(int val)
            {
                //  Get previous size of queue
                int s = q.size();
                q.push(val);
                for (int i=0; i<s; i++)
                {
                    q.push(q.front());
                    // this will delete front element
                    q.pop();
                }
            }
            // Removes the top element
            void pop()
            {
                if (q.isEmpty())
                    cout << "No elements"<<endl;
                else
                    q.pop();
            }

            // Returns top of stack
            int top()
            {
                return (q.isEmpty())? -1 : q.front();
            }
        };

int main()
{
    Stack s;
    s.push(10);
    s.push(20);
    cout << s.top() << endl;
    s.pop();
    s.push(30);
    s.pop();
    cout << s.top() << endl;
    return 0;
}

