#include <iostream>
using namespace std;
struct TreeNode
        {
        public:
            int val;
            TreeNode* left;
            TreeNode* right;
            TreeNode() : val(0), left(nullptr), right(nullptr) {}
            TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
            TreeNode(int x, TreeNode* left, TreeNode* right) : val(x), left(left), right(right) {}
        };
class Solution
        {
        public:
            TreeNode* root;

            Solution()
            {
                root = NULL;
            }
            bool isSymmetric(TreeNode* root)
            {
                if (root == NULL)
                    return true;
                return check(root->left, root->right);
            }
            bool check(TreeNode* left, TreeNode* right)
            {
                if ((left == NULL) && (right == NULL))
                {
                    return true;
                }
                else if ((left != NULL) && (right != NULL))
                {
                    return (left->val == right->val) &&
                    check(left->right, right->left) &&
                    check(left->left, right->right);
                }
                return false;
            }

        };
int main()
{
    Solution s;

    // Test case #1

    TreeNode* root1 = new TreeNode(1);
    root1->left = new TreeNode(2);
    root1->right = new TreeNode(2);
    root1->left->left = new TreeNode(3);
    root1->left->right = new TreeNode(4);
    root1->right->left = new TreeNode(4);
    root1->right->right = new TreeNode(3);
    if (s.isSymmetric(root1))
        cout << "Test case 1 : " << "True" << endl;
    else
        cout << "Test case 1 : " << "False" << endl;
    delete(root1);

    // Test case #2

    TreeNode* root2 = new TreeNode(1);
    root2->left = new TreeNode(2);
    root2->right = new TreeNode(2);
    root2->left->left = new TreeNode(NULL);
    root2->left->right = new TreeNode(3);
    root2->right->left = new TreeNode(NULL);
    root2->right->right = new TreeNode(3);
    if (s.isSymmetric(root2))
        cout << "Test case 2 : " << "True" << endl;
    else
        cout << "Test case 2 : " << "False" << endl;
    delete(root2);

    // Test case #3

    TreeNode* root3 = new TreeNode(8);
    root3->left = new TreeNode(10);
    root3->right = new TreeNode(10);
    root3->left->left = new TreeNode(12);
    root3->left->right = new TreeNode(14);
    root3->right->left = new TreeNode(14);
    root3->right->right = new TreeNode(12);
    if (s.isSymmetric(root3))
        cout << "Test case 3 : " << "True" << endl;
    else
        cout << "Test case 3 : " << "False" << endl;
    delete(root3);

    // Test case #4

    TreeNode* root4 = new TreeNode(1);
    root4->left = new TreeNode(2);
    root4->right = new TreeNode(3);
    root4->left->left = new TreeNode(NULL);
    root4->left->right = new TreeNode(5);
    root4->right->left = new TreeNode(NULL);
    root4->right->right = new TreeNode(6);
    if (s.isSymmetric(root4))
        cout << "Test case 4 : " << "True" << endl;
    else
        cout << "Test case 4 : " << "False" << endl;
    delete(root4);


    // Test case #5

    TreeNode* root5 = new TreeNode(2);
    root5->left = new TreeNode(2);
    root5->right = new TreeNode(2);
    root5->left->left = new TreeNode(NULL);
    root5->left->right = new TreeNode(5);
    root5->right->left = new TreeNode(NULL);
    root5->right->right = new TreeNode(5);
    root5->left->left = new TreeNode(NULL);
    root5->left->right = new TreeNode(5);
    root5->right->left = new TreeNode(NULL);
    root5->right->right = new TreeNode(6);
    if (s.isSymmetric(root5))
        cout << "Test case 5 : " << "True" << endl;
    else
        cout << "Test case 5 : " << "False" << endl;
    delete(root5);

    return 0;
}

