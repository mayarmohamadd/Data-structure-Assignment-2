#include <bits/stdc++.h>
using namespace std;

struct TreeNode {
    int val;

    TreeNode *left, *right;

    TreeNode() : val(0), left(nullptr), right(nullptr) {}

    explicit TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}

    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left),right(right) {}
};

class Solution{
public:
    bool isSameTree(TreeNode* x, TreeNode* y) {

        if (x == nullptr && y == nullptr) {
            return true;
        }

        return (x && y) && (x->val == y->val) && isSameTree(x->left, y->left) && isSameTree(x->right, y->right);
    }
};

int main() {

    Solution s;

    //insert to first tree
    TreeNode* leftTree1;
    leftTree1 = new TreeNode(15);
    leftTree1->left = new TreeNode(10);
    leftTree1->right = new TreeNode(20);

    //insert to second tree
    TreeNode* rightTree1;
    rightTree1 = new TreeNode(15);
    rightTree1->left = new TreeNode(10);
    rightTree1->right = new TreeNode(20);

    //check if the two tree are equal
    if(s.isSameTree(leftTree1, rightTree1))
        cout<<"True"<<endl;

    else
        cout<<"False"<<endl;

    //-------------------------------------------------------------------------/

    //insert to first tree
    TreeNode* leftTree2;
    leftTree2 = new TreeNode(1);
    leftTree2->left = new TreeNode(2);

    //insert to second tree
    TreeNode* rightTree2;
    rightTree2 = new TreeNode(1);
    rightTree2->left = new TreeNode();
    rightTree2->right = new TreeNode(2);

    //check if the two tree are equal
    if(s.isSameTree(leftTree2, rightTree2))
        cout<<"True"<<endl;

    else
        cout<<"False"<<endl;

    //-------------------------------------------------------------------------/

    //insert to first tree
    TreeNode* leftTree3;
    leftTree3 = new TreeNode(1);
    leftTree3->left = new TreeNode(2);
    leftTree3->right = new TreeNode(1);

    //insert to second tree
    TreeNode* rightTree3;
    rightTree3 = new TreeNode(1);
    rightTree3->left = new TreeNode(1);
    rightTree3->right = new TreeNode(2);

    //check if the two tree are equal
    if(s.isSameTree(leftTree3, rightTree3))
        cout<<"True"<<endl;

    else
        cout<<"False"<<endl;

    return 0;
}

