#include <iostream>
using namespace std;
class node
{
public:
    string val;
    node *left = NULL, *right = NULL;
    node(string x)
    {
        val = x;
    }
};
int Int(string s)
{
    int num = 0;
    if(s[0]!='-')
        for (int i=0; i<s.length(); i++)
             num = num*10 + (int(s[i])-48);
    else
    {
        for (int i=1; i<s.length(); i++)
            num = num*10 + (int(s[i])-48);
        num = num*-1;
    }

    return num;
}
int eva(node* root)
{
    if (!root)
    {
        cout<<"Tree is empty...!"<<endl;
         return 0;
    }
    if (!root->left && !root->right)
        return Int(root->val);

    int l_val = eva(root->left);
    int r_val = eva(root->right);

    if (root->val=="+")
        return l_val+r_val;

    else if (root->val=="-")
        return l_val-r_val;

    else if (root->val=="*")
        return l_val*r_val;

    else if (root->val=="/")
        return l_val/r_val;
}
int main()
{

     //test case1  //19
    node *root = new node("+");
    root->left = new node("3");
    root->right = new node("*");
    root->right->right = new node("/");
    root->right->left = new node("4");
    root->right->right->left = new node("8");
    root->right->right->right = new node("2");
    cout <<"Test Case 1: "<< eva(root) << endl;
    delete(root);

    //test case2   //60
    node *root1 = new node("+");
    root1->left = new node("*");
    root1->left->left = new node("5");
    root1->left->right = new node("-4");
    root1->right = new node("-");
    root1->right->left = new node("100");
    root1->right->right = new node("20");
    cout <<"Test Case 2: "<< eva(root1) << endl;
     delete(root1);

     //test case3   //110
    node *root2 = new node("+");
    root2->left = new node("*");
    root2->left->left = new node("5");
    root2->left->right = new node("4");
    root2->right = new node("-");
    root2->right->left = new node("100");
    root2->right->right = new node("/");
    root2->right->right->left = new node("20");
    root2->right->right->right = new node("2");
    cout << "Test Case 3: "<< eva(root2)<<endl;
     delete(root2);

    //test case4   //28
    node *root3 = new node("+");
    root3->right=new node("/");
    root3->right->right=new node("7");
    root3->right->left=new node("21");
    root3->left=new node("*");
    root3->left->right=new node("5");
    root3->left->left=new node("-");
    root3->left->left->right=new node("5");
    root3->left->left->left=new node("10");
    cout << "Test Case 4: "<< eva(root3)<<endl;
    delete(root3);


    //test case5   //100
    node *root4 = new node("+");
    root4->right=new node("-");
    root4->right->right=new node("20");
    root4->right->left=new node("100");
    root4->left=new node("*");
    root4->left->right=new node("4");
    root4->left->left=new node("5");
    cout << "Test Case 5: "<< eva(root4)<<endl;
    delete(root4);

    return 0;
}
