#include<bits/stdc++.h>
#include<iostream>
using namespace std;
struct node{
    int data;
    node *left;
    node *right;
    //to creat new node!
    node(int d){
        data=d;
        this->left= this->right= nullptr;
    }
}*r;
//function to flip tree as mirror!!
void Flip(node * Node){
    if (Node== nullptr)
        return;
    else{
    node* temp;
    Flip(Node->left);
    Flip(Node->right);
    temp=Node->left;
    Node->left=Node->right;
    Node->right=temp;}
}
//insert function!!
void insert(const int& el) {
    node *p = r, *prev = 0;
    while (p != 0) { // find a place for inserting new node;
        prev = p;
        if (el < p->data)
            p = p->left;
        else p = p->right;
    }
    if (r == 0) // tree is empty;
        r = new  node (el);
    else if (el < prev->data)
        prev->left = new node(el);
    else prev->right = new node(el);
}
//print element from smaller to greater num->LVR !!
void inorder(node* temp){
    if(temp== nullptr)
        return;
    inorder(temp->left);
    cout<<temp->data<<"\t";
    inorder(temp->right);
}
//print element by preorde->VLR!!!
void prorder(node* temp){
    if(temp== nullptr)
        return;
    cout<<temp->data<<"   ";
    prorder(temp->left);
    prorder(temp->right);
}

int main(){
    //First test Case!!
    cout<<"First test Case:  \n";
    cout<<"..................\n";
   node* top= new node(1);
   top->left= new node(2);
   top->right= new node(3);
   top->left->left= new node(4);
   top->left->right= new node(5);
   cout<<"original tree is\n";
    inorder(top);
    cout<<endl;
    cout<<"Flip tree is\n";
    Flip(top);
    inorder(top);
    cout<<endl;
    cout<<"----------------------------------------------------\n";
    //second test Case!!
    cout<<"second test Case:  \n";
    cout<<"..................\n";
    node* t= new node(5);
    t->left= new node(6);
    t->right= new node(9);
    t->left->left= new node(7);
    t->left->right= new node(8);
    t->right->right= new node(10);
    cout<<"original tree is\n";
    inorder(t);
    cout<<endl;
    cout<<"Flip tree is\n";
    Flip(t);
    inorder(t);
    cout<<endl;
    cout<<"----------------------------------------------------\n";
    //THIRD test Case!!
    cout<<"third test Case:  \n";
    cout<<"..................\n";
    node* to= new node(1);
    to->left= new node(5);
    to->right= new node(2);
    to->left->left= new node(7);
    to->left->right= new node(6);
    to->right->right= new node(3);
    cout<<"original tree is\n";
    inorder(to);
    cout<<endl;
    cout<<"Flip tree is\n";
    Flip(to);
    inorder(to);
    cout<<endl;
    //FouTH test Case!!
    cout<<"----------------------------------------------------\n";
    cout<<"Fourth test Case:  \n";
    cout<<"..................\n";
    node* n= new node(50);
    n->left= new node(53);
    n->right= new node(20);
    n->right->left= new node(11);
    n->right->right= new node(22);
    n->left->left= new node(52);
    n->left->right= new node(78);
    cout<<"original tree is\n";
    inorder(n);
    cout<<endl;
    cout<<"Flip tree is\n";
    Flip(n);
    inorder(n);
    cout<<endl;
    cout<<"----------------------------------------------------\n";
    //FIFTH test Case!!!
    cout<<"Fifth test Case:  \n";
    cout<<"..................\n";
    node* T= new node(8);
    T->left= new node(3);
    T->right= new node(10);
    T->right->right= new node(14);
    T->right->right->left= new node(13);
    T->left->left= new node(1);
    T->left->right= new node(6);
    T->left->right->left= new node(4);
    T->left->right->right= new node(7);
    cout<<"original tree is\n";
    inorder(T);
    cout<<endl;
    cout<<"Flip tree is\n";
    Flip(T);
    inorder(T);
    cout<<endl;
    cout<<"----------------------------------------------------\n";
}