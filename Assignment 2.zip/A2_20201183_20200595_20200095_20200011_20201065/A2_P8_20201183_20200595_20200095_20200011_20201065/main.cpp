#include <iostream>
#include <string>
using namespace std;
int c=0;
//function to search position in arr!
int get_index(string in,char ss,int size){
    c++;
    for(int i=0;i<size;i++){
        if(in[i]==ss)
            return i;
    }
    return -1;
}
//function to print postorder from inorder and preorder!
void postOrder(string pre,string in,int size){
    //get index of root!
      int idex=get_index(in,pre[0],size);
    //int idex=in.find(pre[0]);

    //if tree has element in left!
    if(idex!=0){
        postOrder(pre.substr(1),in,idex);
    }

    if(idex!=size-1){
        postOrder(pre.substr(idex+1),in.substr(idex+1),size-idex-1);
    }
    if(pre!=""&&in!="")
        cout<<pre[0];
}
void printPostOrder (string preorder, string inorder){
    postOrder(preorder,inorder,inorder.size());
}

int main(){
    //first test case!
    printPostOrder("ABFGC", "FBGAC");
    cout<<endl;
    //second test case!
    printPostOrder("ABDECFG", "DBEAFCG");
    cout<<endl;
    //Third test case!
    printPostOrder("ABDHIECFGJ", "HDIBEAFCJG");
    cout<<endl;
    //Fourth test case!
    printPostOrder("FBADCEGIH", "ABCDEFGHI");
    cout<<endl;
    //Fifth test case!
    printPostOrder("ABCGDEF", "GCBDAFE");
    cout<<endl;
}
