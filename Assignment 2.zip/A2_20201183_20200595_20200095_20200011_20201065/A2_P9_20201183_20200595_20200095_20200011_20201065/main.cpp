#include <bits/stdc++.h>
using namespace std;
//definition of a node
class node {
public:
    int data;
    node* left;
    node* right;
};
void mirror(node* n);
bool isStructSame(node* a, node* b);
//The next function is foldable function
bool isFoldable(node* root)
{
    bool r;


    if (root == NULL)
        return true;

    mirror(root->left);


    r = isStructSame(root->left, root->right);

    mirror(root->left);

    return r;
}
bool isStructSame(node* a, node* b)
{
    if (a == NULL && b == NULL) {
        return true;
    }

    if (a != NULL && b != NULL && isStructSame(a->left, b->left) && isStructSame(a->right, b->right)) {
        return true;
    }
    return false;
}

void mirror(node* Node)
{
    if (Node == NULL)
        return;
    else {
        node* temp;


        mirror(Node->left);
        mirror(Node->right);


        temp = Node->left;
        Node->left = Node->right;
        Node->right = temp;
    }
}

node* newNode(int data)
{
    node* Node = new node();
    Node->data = data;
    Node->left = NULL;
    Node->right = NULL;

    return (Node);
}
void test1()
{
    /* The constructed binary tree is
        1
       / \
       2  3
       \ /
       4 5
   */
    node* root = newNode(1);
    root->left = newNode(2);
    root->right = newNode(3);
    root->right->left = newNode(4);
    root->left->right = newNode(5);

    if (isFoldable(root) == 1) {
        cout << "tree is foldable";
    }
    else {
        cout << "\ntree is not foldable";
    }
}
void test2()
{
    /* The constructed binary tree is
        10
      /  \
     7   15
    /    /
   5   11
   */
    node* root = newNode(10);
    root->left = newNode(7);
    root->right = newNode(15);
    root->right->left = newNode(11);
    root->left->left = newNode(5);


    if (isFoldable(root) == 1) {
        cout << "tree is foldable";
    }
    else {
        cout << "\ntree is not foldable";
    }


}
void test3()
{
    /* The constructed binary tree is

       10
     /   \
    7     15
  /  \    /
 9   10  12
  */
    node* root = newNode(10);
    root->left = newNode(7);
    root->right = newNode(15);
    root->right->left = newNode(12);
    root->left->left = newNode(9);
    root->left->right=newNode(10);

    if (isFoldable(root) == 1) {
        cout << "tree is foldable";
    }
    else {
        cout << "\ntree is not foldable";
    }
    cout<<endl;

}
void test4()
{

    /* The constructed binary tree is
       10
     /  \
    7    15
   /      \
  9       11


  */
    node* root = newNode(10);
    root->left = newNode(7);
    root->right = newNode(15);
    root->left->left = newNode(9);
    root->right->right=newNode(11);

    if (isFoldable(root) == 1) {
        cout << "tree is foldable";
    }
    else {
        cout << "\ntree is not foldable";
    }
    cout<<endl;
}
void test5()
{
    /* The constructed binary tree is

    10
  /   \
 7     15
/  \    / \
9   10  12  17
*/
    node* root = newNode(10);
    root->left = newNode(7);
    root->right = newNode(15);
    root->right->left = newNode(12);
    root->left->left = newNode(9);
    root->left->right=newNode(10);
    root->right->right=newNode(17);

    if (isFoldable(root) == 1) {
        cout << "tree is foldable";
    }
    else {
        cout << "\ntree is not foldable";
    }
    cout<<endl;
}
int main(void)
{
    test1();
    test2();
    test3();
    test4();
    test5();
    return 0;
}
